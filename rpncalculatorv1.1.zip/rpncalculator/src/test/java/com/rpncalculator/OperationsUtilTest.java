package com.rpncalculator;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.rpncalculator.operation.AddOperation;
import com.rpncalculator.operation.ClearOperation;
import com.rpncalculator.operation.MultiplyOperation;
import com.rpncalculator.operation.Operation;
import com.rpncalculator.operation.SqrtOperation;
import com.rpncalculator.operation.SubtractOperation;
import com.rpncalculator.operation.UndoOperation;
import com.rpncalculator.utils.OperationsUtil;

@RunWith(PowerMockRunner.class)
@PrepareForTest(OperationsUtil.class)
public class OperationsUtilTest {
	@Test
	public void testOperations() {
		Operation addOperation = OperationsUtil.getOperation("+");
		assertTrue(addOperation instanceof AddOperation);
		Operation subOperation = OperationsUtil.getOperation("-");
		assertTrue(subOperation instanceof SubtractOperation);
		Operation sqrtOperation = OperationsUtil.getOperation("sqrt");
		assertTrue(sqrtOperation instanceof SqrtOperation);
		Operation undoOperation = OperationsUtil.getOperation("undo");
		assertTrue(undoOperation instanceof UndoOperation);
		Operation clearOperation = OperationsUtil.getOperation("clear");
		assertTrue(clearOperation instanceof ClearOperation);
		Operation mulOperation = OperationsUtil.getOperation("*");
		assertTrue(mulOperation instanceof MultiplyOperation);
	}

}
