package com.rpncalculator.observer;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.EmptyStackException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.rpncalculator.utils.StackOperations;

@RunWith(PowerMockRunner.class)
@PrepareForTest(StackOperations.class)
public class StackOperationsTest {
	@Test
	public void testPush() {
		StackOperations.push(new BigDecimal(2));
		DecimalFormat df = StackOperations.getNumberFormat();
		assertEquals(df.format(StackOperations.pop()), "2");
	}
	@Test(expected=EmptyStackException.class)
	public void testPop() {
		StackOperations.push(new BigDecimal(6));
		StackOperations.pop();
		StackOperations.pop();
	}
	@Test(expected=EmptyStackException.class)
	public void testClear() {
		StackOperations.push(new BigDecimal(6));
		StackOperations.clear();
		StackOperations.pop();
	}
	@Test
	public void testUndo() {
		StackOperations.push(new BigDecimal(2));
		StackOperations.push(new BigDecimal(5));
		StackOperations.push(new BigDecimal(3));
		DecimalFormat df = StackOperations.getNumberFormat();
		StackOperations.undo();
		assertEquals(df.format(StackOperations.pop()), "5");
	}
}
