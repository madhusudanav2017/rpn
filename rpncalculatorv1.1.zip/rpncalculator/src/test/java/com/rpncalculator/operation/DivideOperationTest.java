package com.rpncalculator.operation;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.junit.Test;
import org.mockito.Mockito;

import com.rpncalculator.utils.StackOperations;

public class DivideOperationTest {
	@Test
	public void testAdditionOperation() {
		StackOperations.push(new BigDecimal(6));
		StackOperations.push(new BigDecimal(3));
		Operation divide = Mockito.spy(new DivideOperation());
		divide.operation();
		DecimalFormat df = StackOperations.getNumberFormat();
		assertEquals(df.format(StackOperations.pop()), "2");
	}
}
