package com.rpncalculator.operation;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.junit.Test;
import org.mockito.Mockito;

import com.rpncalculator.utils.StackOperations;

public class SqrtOperationTest {
	@Test
	public void testAdditionOperation() {
		StackOperations.push(new BigDecimal(9));
		Operation sqrt = Mockito.spy(new SqrtOperation());
		sqrt.operation();
		DecimalFormat df = StackOperations.getNumberFormat();
		assertEquals(df.format(StackOperations.pop()), "3");
	}
}
