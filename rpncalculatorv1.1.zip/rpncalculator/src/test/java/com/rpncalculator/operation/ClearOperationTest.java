package com.rpncalculator.operation;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;
import org.mockito.Mockito;

import com.rpncalculator.utils.StackOperations;

public class ClearOperationTest {
	@Test
	public void testClearOperation() {
		StackOperations.push(new BigDecimal(2));
		StackOperations.push(new BigDecimal(5));
		Operation clear = Mockito.spy(new ClearOperation());
		clear.operation();
		assertEquals(StackOperations.size(), 0);
	}
}
