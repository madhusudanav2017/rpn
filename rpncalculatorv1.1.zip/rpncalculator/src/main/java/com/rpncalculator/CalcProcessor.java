package com.rpncalculator;
@FunctionalInterface
public interface CalcProcessor {
	public void process();
}
