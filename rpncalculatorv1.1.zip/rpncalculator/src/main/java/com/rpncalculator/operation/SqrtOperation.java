package com.rpncalculator.operation;

import java.math.BigDecimal;

import com.rpncalculator.utils.StackOperations;

public class SqrtOperation implements Operation {

	public void operation() {
		if (StackOperations.size() < 1)
			throw new IllegalArgumentException("operator : " + this.toString() + " has insufficient parameters");
		BigDecimal x = StackOperations.pop();
		StackOperations.push(new BigDecimal(Math.sqrt(x.doubleValue())));
	}
}
