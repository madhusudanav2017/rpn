package com.rpncalculator.operation;
@FunctionalInterface
public interface Operation {
	void operation();
}
