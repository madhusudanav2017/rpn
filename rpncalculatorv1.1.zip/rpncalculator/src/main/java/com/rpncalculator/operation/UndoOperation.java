package com.rpncalculator.operation;

import com.rpncalculator.utils.StackOperations;


public class UndoOperation implements Operation {
	public void operation() {
		StackOperations.undo();
	}
	}
