package com.rpncalculator.operation;

import com.rpncalculator.utils.StackOperations;

public class ClearOperation implements Operation {
	public void operation() {
		StackOperations.clear();
	}
}
