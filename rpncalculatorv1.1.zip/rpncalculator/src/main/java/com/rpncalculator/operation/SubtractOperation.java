package com.rpncalculator.operation;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.rpncalculator.utils.StackOperations;

public class SubtractOperation implements Operation {

	public void operation() {
		if (StackOperations.size() < 2)
			throw new IllegalArgumentException("operator : " + this.toString() + " has insufficient parameters");
		BigDecimal x = StackOperations.pop();
		BigDecimal y = StackOperations.pop();
		StackOperations.push(y.subtract(x).setScale(15, RoundingMode.FLOOR));
	}
}
