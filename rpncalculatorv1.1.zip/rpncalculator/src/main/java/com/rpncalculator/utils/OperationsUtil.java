package com.rpncalculator.utils;

import com.rpncalculator.Operations;
import com.rpncalculator.operation.AddOperation;
import com.rpncalculator.operation.ClearOperation;
import com.rpncalculator.operation.DivideOperation;
import com.rpncalculator.operation.MultiplyOperation;
import com.rpncalculator.operation.Operation;
import com.rpncalculator.operation.SqrtOperation;
import com.rpncalculator.operation.SubtractOperation;
import com.rpncalculator.operation.UndoOperation;

public class OperationsUtil {
	private static final Operations operations = new Operations();
	static {
		operations.add("+", new AddOperation());
		operations.add("-", new SubtractOperation());
		operations.add("*", new MultiplyOperation());
		operations.add("/", new DivideOperation());
		operations.add("sqrt", new SqrtOperation());
		operations.add("clear", new ClearOperation());
		operations.add("undo", new UndoOperation());
	}

	public static Operation getOperation(String key) {
		return operations.get(key);
	}

	public static boolean isOperator(String key) {
		return operations.get(key) != null;
	}
}
