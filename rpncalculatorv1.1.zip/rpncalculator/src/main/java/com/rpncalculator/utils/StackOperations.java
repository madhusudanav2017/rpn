package com.rpncalculator.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Stack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StackOperations {
	private final static Stack<BigDecimal> currentStack = new Stack<BigDecimal>();
	private final static Stack<BigDecimal> historyStack = new Stack<BigDecimal>();
	private static final Logger LOGGER = LoggerFactory.getLogger(StackOperations.class);

	public static void push(BigDecimal item) {
		currentStack.push(item);
		historyStack.push(item);
	}

	public static BigDecimal pop() {
		return currentStack.pop();
	}

	public static void clear() {
		currentStack.clear();
		historyStack.clear();
	}

	public static void undo() {
		currentStack.clear();
		historyStack.pop();
		currentStack.addAll(historyStack);
	}

	public static int size() {
		return currentStack.size();
	}

	public static void print() {
		DecimalFormat df = getNumberFormat();
		StringBuilder builder = new StringBuilder("Stack:");
		for (BigDecimal value : currentStack) {
			builder.append(df.format(value)).append(" ");
		}
		System.out.println(builder.toString());
	}

	public static DecimalFormat getNumberFormat() {
		DecimalFormat df = new DecimalFormat("#0.##########");
		df.setRoundingMode(RoundingMode.DOWN);
		return df;
	}

	public static void printError(String error) {
		LOGGER.error(error);
		System.out.println(error);
	}

}
