package com.rpncalculator;

import java.math.BigDecimal;
import java.util.Scanner;

import com.rpncalculator.utils.OperationsUtil;
import com.rpncalculator.utils.StackOperations;

public class CalcProcessorImpl implements CalcProcessor {
	private boolean loop = false;
	public void process() {
		do {
			String[] expArray = getInput();
			if (expArray == null || expArray.length == 0) {
				break;
			}
			int position = 0;
			for (String element : expArray) {
				if (OperationsUtil.isOperator(element)) {
					try {
						OperationsUtil.getOperation(element).operation();
					} catch (IllegalArgumentException iaex) {
						position = position + 1;
						String errorMsg = new StringBuilder("Operator: ").append(element).append("position")
								.append("): insufficient parameters").toString();
						StackOperations.printError(errorMsg);
						break;
					}
				} else if (element != null && element != "") {
					try {
						BigDecimal number = new BigDecimal(element);
						StackOperations.push(number);
					} catch (NumberFormatException nex) {
						String errorMsg = new StringBuilder("Element : ").append(element).append(" is not valid")
								.toString();
						StackOperations.printError(errorMsg);
					}
				}
				position = position + 2;
			}

			StackOperations.print();
		} while (loop);
	}

	private String[] getInput() {
		Scanner sc = new Scanner(System.in);
		String expression = sc.nextLine();
		String[] expArray = null;
		if (expression != null && expression.length() != 0) {
			expression = expression.trim();
			expArray = expression.split("\\s+");
		}
		return expArray;
	}

	public boolean isLoop() {
		return loop;
	}

	public void setLoop(boolean loop) {
		this.loop = loop;
	}

}
