package com.rpncalculator.exception;

public class RPNCalcInternalRuntimeException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RPNCalcInternalRuntimeException(String message) {
		super(message);
	}

	public RPNCalcInternalRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}
}
