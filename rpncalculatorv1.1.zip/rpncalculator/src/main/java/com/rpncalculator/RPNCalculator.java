package com.rpncalculator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rpncalculator.exception.RPNCalcInternalRuntimeException;
import com.rpncalculator.operation.AddOperation;
import com.rpncalculator.operation.ClearOperation;
import com.rpncalculator.operation.DivideOperation;
import com.rpncalculator.operation.MultiplyOperation;
import com.rpncalculator.operation.SqrtOperation;
import com.rpncalculator.operation.SubtractOperation;
import com.rpncalculator.operation.UndoOperation;

/**
 * <p>
 * RPN Calculator class process calculator operations like addition
 * {@link AddOperation}}, subtraction {@link SubtractOperation}}, division
 * {@link DivideOperation}}, multiplication {@link MultiplyOperation}}, square
 * Root {@link SqrtOperation}}, undo the current action {@link UndoOperation}},
 * clear the execution {@link ClearOperation}}.
 * </p>
 * 
 * @author Madhusudana V
 *
 */
public class RPNCalculator {
	private static final Logger LOGGER = LoggerFactory.getLogger(RPNCalculator.class);
	private CalcProcessor processor;

	public RPNCalculator() {
	}

	/**
	 * <p>
	 * Main method to start Calculator Software.
	 * </p>
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		LOGGER.debug("RPN Calculator Starting...");
		/*
		 * If Spring Framework IOC used, CalcProcessorImpl can binded in
		 * configuration (Loosely coupled).
		 */
		RPNCalculator calculator = new RPNCalculator();
		CalcProcessorImpl calcProcessor = new CalcProcessorImpl();
		calcProcessor.setLoop(true);
		calculator.setProcessor(calcProcessor);
		calculator.callProcess();
	}

	/**
	 * <p>
	 * Start the calculator process.
	 * </p>
	 */
	public void callProcess() {
		if (getProcessor() == null) {
			LOGGER.error("process is null, hence unable to start Calculator process.");
			throw new RPNCalcInternalRuntimeException(
					"Unable to start Calculator Process, Please contact Application Support.");
		}
		getProcessor().process();
	}

	public CalcProcessor getProcessor() {
		return processor;
	}

	public void setProcessor(CalcProcessor processor) {
		this.processor = processor;
	}

}
