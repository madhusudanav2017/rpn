package com.rpncalculator;

import java.util.HashMap;
import java.util.Map;

import com.rpncalculator.operation.Operation;

public class Operations {

	Map<String, Operation> operations;

	public Operations() {
		operations = new HashMap<String, Operation>();
	}

	public void add(String key, Operation operation) {
		operations.put(key, operation);
	}

	public Operation get(String key) {
		return operations.get(key);
	}
}
