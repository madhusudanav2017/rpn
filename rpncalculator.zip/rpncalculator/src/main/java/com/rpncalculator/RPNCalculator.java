package com.rpncalculator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rpncalculator.exception.RPNCalcInternalRuntimeException;
import com.rpncalculator.operation.CalcOperations;

/**
 * <p>
 * RPN Calculator class process calculator operations like addition
 * {@link CalcOperations}}, subtraction {@link CalcOperations}}, division
 * {@link CalcOperations}}, multiplication {@link CalcOperations}}, square Root
 * {@link CalcOperations}}, undo the current action {@link CalcOperations}},
 * clear the execution {@link CalcOperations}}.
 * </p>
 * 
 * @author Madhusudana V
 *
 */
public class RPNCalculator {
	private static final Logger LOGGER = LoggerFactory.getLogger(RPNCalculator.class);
	private CalcProcessor processor;

	public RPNCalculator() {
	}

	/**
	 * <p>
	 * Main method to start Calculator Software.
	 * </p>
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		RPNCalculator calculator = new RPNCalculator();
		CalcProcessorImpl calcProcessor = new CalcProcessorImpl();
		calcProcessor.setLoop(true);
		calculator.setProcessor(calcProcessor);
		calculator.callProcess();
	}

	/**
	 * <p>
	 * Start the calculator process.
	 * </p>
	 */
	public void callProcess() {
		if (getProcessor() == null) {
			LOGGER.error("process is null, hence unable to start Calculator process.");
			throw new RPNCalcInternalRuntimeException(
					"Unable to start Calculator Process, Please contact Application Support.");
		}
		getProcessor().process();
	}

	public CalcProcessor getProcessor() {
		return processor;
	}

	public void setProcessor(CalcProcessor processor) {
		this.processor = processor;
	}

}
