package com.rpncalculator;

import java.math.BigDecimal;
import java.util.Scanner;
import java.util.Stack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rpncalculator.helper.CalcOperationsHelper;
import com.rpncalculator.helper.OperationEnumHelper;
import com.rpncalculator.helper.PrintHelper;
import com.rpncalculator.operation.CalcOperations;
import com.rpncalculator.operation.Operation;
import com.rpncalculator.vo.StackItem;
/**
 * 
 * @author Madhusudana V
 *
 */
public class CalcProcessorImpl implements CalcProcessor {
	private static final Logger LOGGER = LoggerFactory.getLogger(CalcProcessorImpl.class);
	private boolean loop = false;
	private final Stack<StackItem> historyStack = new Stack<>();

	public void process() {
		do {
			String[] expArray = getInput();
			if (expArray == null || expArray.length == 0) {
				break;
			}
			int position = 0;
			StackItem item = setCurrentItem();
			for (String element : expArray) {
				Operation operation = null;
				if ((operation = OperationEnumHelper.lookupOperation(element)) != null) {
					try {
						compute(item, element, operation);
					} catch (IllegalArgumentException iaex) {
						position = catchBlockOperations(position, element);
						break;
					}
				} else if (element != null && element != "") {
					try {
						BigDecimal number = new BigDecimal(element);
						item.getStack().push(number);
					} catch (NumberFormatException nex) {
						position = catchBlockOperations(position, element);
					}
				}
				position = position + 2;
			}
			if (!item.getStack().isEmpty()) {
				updateOnHistoryStack(item);
			}
			PrintHelper.printItem(item);
		} while (loop);
	}

	private int catchBlockOperations(int position, String element) {
		position = position + 1;
		String errorMsg = CalcOperationsHelper.prepareErrorMsg(position, element);
		LOGGER.error(errorMsg);
		PrintHelper.printError(errorMsg);
		return position;
	}

	private void updateOnHistoryStack(StackItem item) {
		try {
			historyStack.push((StackItem) item.clone());
		} catch (CloneNotSupportedException e) {
			LOGGER.error(e.getMessage());
			PrintHelper.printError("Clone not supported Exception");
		}
	}

	private void compute(StackItem item, String element, Operation operation) {
		BigDecimal result = operation.execute(item);
		if (result != null) {
			item.getStack().push(result);
		} else {
			undoOperations(item, element);
		}
	}

	private void undoOperations(StackItem item, String element) {
		if (historyStack.size() > 0) {
			if (CalcOperations.CLEAR_OPERATION.operationName().equals(element)) {
				historyStack.clear();
			} else if (CalcOperations.UNDO_OPERATION.operationName().equals(element)) {
				historyStack.peek().getStack().pop();
				if (item.getStack().size() <= 1 && historyStack.size() > 0) {
					historyStack.pop();
					if (historyStack.size() > 0) {
						item.getStack().addAll(historyStack.pop().getStack());
					}
				}
			}
		}
	}

	private StackItem setCurrentItem() {
		StackItem item = null;
		if (historyStack.empty()) {
			item = new StackItem();
		} else {
			try {
				item = (StackItem) historyStack.peek().clone();
			} catch (CloneNotSupportedException e) {
				LOGGER.error(e.getMessage());
				PrintHelper.printError("Clone not supported Exception");
			}
		}
		return item;
	}

	private String[] getInput() {
		Scanner sc = new Scanner(System.in);
		String[] expArray = null;
		try {
			String expression = sc.nextLine();

			if (expression != null && expression.length() != 0) {
				expression = expression.trim();
				expArray = expression.split("\\s+");
			}
		} finally {
			if (!loop)
				sc.close();
		}
		return expArray;
	}

	public boolean isLoop() {
		return loop;
	}

	public void setLoop(boolean loop) {
		this.loop = loop;
	}

}
