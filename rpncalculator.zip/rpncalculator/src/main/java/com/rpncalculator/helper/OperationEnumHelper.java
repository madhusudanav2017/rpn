package com.rpncalculator.helper;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.rpncalculator.operation.CalcOperations;
import com.rpncalculator.operation.Operation;
import com.rpncalculator.vo.StackItem;

/**
 * 
 * @author Madhusudana V
 *
 */
public class OperationEnumHelper {
	public static Operation lookupOperation(String key) {
		if (key != null && key != "") {
			CalcOperations[] arrayOfEnums = CalcOperations.values();
			for (CalcOperations calcOperation : arrayOfEnums) {
				if (calcOperation.operationName().equals(key)) {
					return calcOperation;
				}
			}
		}
		return null;
	}

	public static void preCheckForTwoInputsOperation(CalcOperations operation, StackItem item) {
		if (item.getStack().size() < 2)
			throwException(operation);
	}

	public static void preCheckForSingleInputOperation(CalcOperations operation, StackItem item) {
		if (item.getStack().size() < 1)
			throwException(operation);
	}

	public static void throwException(CalcOperations operation) {
		if (operation != null) {
			throw new IllegalArgumentException(
					"operator : " + operation.operationName() + " has insufficient parameters");
		}
	}

	public static BigDecimal roundTheResult(BigDecimal result) {
		if (result != null) {
			return result.setScale(15, RoundingMode.FLOOR);
		}
		return null;
	}
}
