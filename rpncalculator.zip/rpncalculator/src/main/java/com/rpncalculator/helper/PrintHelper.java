package com.rpncalculator.helper;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

import com.rpncalculator.vo.StackItem;

public class PrintHelper {
	public static void printItem(StackItem item) {
		DecimalFormat df = getNumberFormat();
		StringBuilder builder = new StringBuilder("Stack:");
		for (BigDecimal value : item.getStack()) {
			builder.append(df.format(value)).append(" ");
		}
		System.out.println(builder.toString());
	}

	public static DecimalFormat getNumberFormat() {
		DecimalFormat df = new DecimalFormat("#0.##########");
		df.setRoundingMode(RoundingMode.DOWN);
		return df;
	}

	public static void printError(String error) {
		System.out.println(error);
	}

}
