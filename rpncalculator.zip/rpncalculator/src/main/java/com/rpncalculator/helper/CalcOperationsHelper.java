package com.rpncalculator.helper;

public class CalcOperationsHelper {
	public static String prepareErrorMsg(int position, String element) {
		String errorMsg = new StringBuilder("Operator ").append(element).append(" (position:").append(position)
				.append("): insufficient parameters").toString();
		return errorMsg;
	}
}
