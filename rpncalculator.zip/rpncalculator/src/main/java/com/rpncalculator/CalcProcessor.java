package com.rpncalculator;

/**
 * <p>
 * API to process calculator operations.
 * </p>
 * 
 * @author Madhusudana V
 *
 */
@FunctionalInterface
public interface CalcProcessor {
	public void process();
}
