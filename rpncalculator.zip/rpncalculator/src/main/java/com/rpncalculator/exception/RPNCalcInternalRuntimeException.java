package com.rpncalculator.exception;

/**
 * <p>
 * This exception is used to handle RPN Calculator internal runtime exceptions.
 * </p>
 * 
 * @author Madhusudana V
 *
 */
public class RPNCalcInternalRuntimeException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RPNCalcInternalRuntimeException(String message) {
		super(message);
	}

	public RPNCalcInternalRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}
}
