package com.rpncalculator.vo;

import java.math.BigDecimal;
import java.util.Stack;

public class StackItem implements Cloneable {
	private Stack<BigDecimal> currentStack = new Stack<>();

	public StackItem() {
	}

	public Stack<BigDecimal> getStack() {
		return currentStack;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object clone() throws CloneNotSupportedException {
		super.clone();
		StackItem item = new StackItem();
		item.currentStack = (Stack<BigDecimal>) currentStack.clone();
		return item;
	}
}
