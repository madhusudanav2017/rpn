package com.rpncalculator.operation;

import java.math.BigDecimal;

import com.rpncalculator.vo.StackItem;

@FunctionalInterface
public interface Operation {
	BigDecimal execute(StackItem item);
}
