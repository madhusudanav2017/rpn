package com.rpncalculator.operation;

import java.math.BigDecimal;

import com.rpncalculator.helper.OperationEnumHelper;
import com.rpncalculator.vo.StackItem;

/**
 * <p>
 * calculator operations like addition {@link CalcOperations}}, subtraction
 * {@link CalcOperations}}, division {@link CalcOperations}}, multiplication
 * {@link CalcOperations}}, square Root {@link CalcOperations}}, undo the
 * current action {@link CalcOperations}}, clear the execution
 * {@link CalcOperations}}.
 * </p>
 * 
 * @author Madhusudana V
 *
 */
public enum CalcOperations implements Operation {
	ADD_OPERATION("+") {
		@Override
		public BigDecimal execute(StackItem item) {
			OperationEnumHelper.preCheckForTwoInputsOperation(CalcOperations.ADD_OPERATION, item);
			BigDecimal result = OperationEnumHelper.roundTheResult(item.getStack().pop().add(item.getStack().pop()));
			return result;
		}

	},
	SUBTRACT_OPERATION("-") {
		@Override
		public BigDecimal execute(StackItem item) {
			OperationEnumHelper.preCheckForTwoInputsOperation(CalcOperations.SUBTRACT_OPERATION, item);
			BigDecimal x = item.getStack().pop();
			BigDecimal result = OperationEnumHelper.roundTheResult(item.getStack().pop().subtract(x));
			return result;
		}
	},
	MULTIPLICATION_OPERATION("*") {
		@Override
		public BigDecimal execute(StackItem item) {
			OperationEnumHelper.preCheckForTwoInputsOperation(CalcOperations.MULTIPLICATION_OPERATION, item);
			BigDecimal result = OperationEnumHelper
					.roundTheResult(item.getStack().pop().multiply(item.getStack().pop()));
			return result;
		}
	},
	DIVIDE_OPERATION("/") {
		@Override
		public BigDecimal execute(StackItem item) {
			OperationEnumHelper.preCheckForTwoInputsOperation(CalcOperations.DIVIDE_OPERATION, item);
			BigDecimal x = item.getStack().pop();
			BigDecimal result = OperationEnumHelper.roundTheResult(item.getStack().pop().divide(x));
			return result;
		}
	},
	SQRT_OPERATION("sqrt") {
		@Override
		public BigDecimal execute(StackItem item) {
			OperationEnumHelper.preCheckForSingleInputOperation(SQRT_OPERATION, item);
			BigDecimal result = OperationEnumHelper
					.roundTheResult(new BigDecimal(Math.sqrt(item.getStack().pop().doubleValue())));
			return result;
		}
	},
	CLEAR_OPERATION("clear") {
		@Override
		public BigDecimal execute(StackItem item) {
			item.getStack().clear();
			return null;
		}
	},
	UNDO_OPERATION("undo") {
		@Override
		public BigDecimal execute(StackItem item) {
			OperationEnumHelper.preCheckForSingleInputOperation(UNDO_OPERATION, item);
			item.getStack().pop();
			return null;
		}
	};
	private String operationName;

	private CalcOperations(String operationName) {
		this.operationName = operationName;
	}

	public String operationName() {
		return operationName;
	}
}
