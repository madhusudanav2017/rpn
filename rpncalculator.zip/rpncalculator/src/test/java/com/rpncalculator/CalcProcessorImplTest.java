package com.rpncalculator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(CalcProcessorImpl.class)
public class CalcProcessorImplTest {
	private static final String METHOD = "getInput";

	@Test
	public void testProcess() throws Exception {
		String response[] = {"3","4","+"};
		CalcProcessorImpl calcProcess = new CalcProcessorImpl();
		CalcProcessorImpl calcProcessSpy = PowerMockito.spy(calcProcess);
		PowerMockito.doReturn(response).when(calcProcessSpy, METHOD);
		calcProcessSpy.process();
		PowerMockito.verifyPrivate(calcProcessSpy, Mockito.times(1)).invoke(METHOD);
	}
}
