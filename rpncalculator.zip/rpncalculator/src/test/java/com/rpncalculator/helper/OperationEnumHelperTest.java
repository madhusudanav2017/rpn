package com.rpncalculator.helper;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;

import com.rpncalculator.RPNTest;
import com.rpncalculator.operation.CalcOperations;

import junit.framework.AssertionFailedError;

public class OperationEnumHelperTest extends RPNTest {
	@Test
	public void testLookupOperation() {
		assertEquals(CalcOperations.ADD_OPERATION, OperationEnumHelper.lookupOperation("+"));
	}

	@Test
	public void testPreCheckForTwoInputsOperation() {
		try {
			OperationEnumHelper.preCheckForTwoInputsOperation(CalcOperations.ADD_OPERATION, prepareTestData());
		} catch (Exception e) {
			throw new AssertionFailedError("failed to print item");
		}
	}

	@Test
	public void testPreCheckForSingleInputsOperation() {
		try {
			OperationEnumHelper.preCheckForSingleInputOperation(CalcOperations.ADD_OPERATION, prepareTestData());
		} catch (Exception e) {
			throw new AssertionFailedError("failed to print item");
		}
	}

	@Test
	public void testRoundTheResult() {
		assertEquals("2", PrintHelper.getNumberFormat()
				.format(OperationEnumHelper.roundTheResult(new BigDecimal(2.0000000000000000000000000000))));
	}
}
