package com.rpncalculator.helper;

import org.junit.Test;

import com.rpncalculator.RPNTest;
import com.rpncalculator.vo.StackItem;

import junit.framework.AssertionFailedError;

public class PrintHelperTest extends RPNTest {
	@Test
	public void testPrintItem() {
		StackItem item = prepareTestData();
		try {
			PrintHelper.printItem(item);
		} catch (Exception e) {
			throw new AssertionFailedError("failed to print item");
		}
	}

	@Test
	public void testPrintError() {
		try {
			PrintHelper.printError("Operator 4+ (position:15): insufficient parameters");
		} catch (Exception e) {
			throw new AssertionFailedError("failed to print item");
		}
	}
}
