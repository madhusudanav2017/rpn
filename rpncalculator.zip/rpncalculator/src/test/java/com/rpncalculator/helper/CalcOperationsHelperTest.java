package com.rpncalculator.helper;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalcOperationsHelperTest {
	@Test
	public void testPrepareErrorMsg() {
		String result=CalcOperationsHelper.prepareErrorMsg(15, "4+");
		assertEquals("Operator 4+ (position:15): insufficient parameters",result);
	}
}
