package com.rpncalculator;

import java.math.BigDecimal;

import com.rpncalculator.vo.StackItem;

public abstract class RPNTest {
	public StackItem prepareTestData() {
		StackItem item = new StackItem();
		item.getStack().push(new BigDecimal(2));
		item.getStack().push(new BigDecimal(5));
		return item;
	}
}
