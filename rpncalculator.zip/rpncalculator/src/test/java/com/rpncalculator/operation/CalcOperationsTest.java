package com.rpncalculator.operation;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.junit.Test;

import com.rpncalculator.RPNTest;
import com.rpncalculator.helper.PrintHelper;
import com.rpncalculator.vo.StackItem;

public class CalcOperationsTest extends RPNTest {
	@Test
	public void testAdditionOperation() {
		StackItem item = prepareTestData();
		Operation add = CalcOperations.ADD_OPERATION;
		BigDecimal result = add.execute(item);
		DecimalFormat df = PrintHelper.getNumberFormat();
		assertEquals("7", df.format(result));
	}
	@Test
	public void testClearOperation() {
		StackItem item = prepareTestData();
		Operation clear = CalcOperations.CLEAR_OPERATION;
		clear.execute(item);
		assertEquals(0, item.getStack().size());
	}

	@Test
	public void testDivisionOperation() {
		StackItem item = prepareTestData();
		Operation divide = CalcOperations.DIVIDE_OPERATION;
		BigDecimal result = divide.execute(item);
		DecimalFormat df = PrintHelper.getNumberFormat();
		assertEquals("0.4", df.format(result));
	}

	@Test
	public void testMultiplicationOperation() {
		StackItem item = prepareTestData();
		Operation multiply = CalcOperations.MULTIPLICATION_OPERATION;
		BigDecimal result = multiply.execute(item);
		DecimalFormat df = PrintHelper.getNumberFormat();
		assertEquals("10", df.format(result));
	}

	@Test
	public void testSqrtOperation() {

		StackItem item = new StackItem();
		item.getStack().push(new BigDecimal(9));
		Operation sqrt = CalcOperations.SQRT_OPERATION;
		BigDecimal result = sqrt.execute(item);
		DecimalFormat df = PrintHelper.getNumberFormat();
		assertEquals("3", df.format(result));
	}

	@Test
	public void testSubtractionOperation() {
		StackItem item = prepareTestData();
		Operation sub = CalcOperations.SUBTRACT_OPERATION;
		BigDecimal result = sub.execute(item);
		DecimalFormat df = PrintHelper.getNumberFormat();
		assertEquals("-3", df.format(result));
	}

	@Test
	public void testUndoOperation() {
		StackItem item = prepareTestData();
		Operation undo = CalcOperations.UNDO_OPERATION;
		undo.execute(item);
		DecimalFormat df = PrintHelper.getNumberFormat();
		assertEquals("2", df.format(item.getStack().pop()));
	}
}
